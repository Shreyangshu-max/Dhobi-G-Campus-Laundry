/* ============================================================
   UI.JS — All interactive UI logic
   Dhobi G Campus Laundry
   ============================================================ */


/* ── SERVICES ACCORDION ─────────────────────────────────────
   Toggles .active on a service item.
   Clicking an open item closes it; clicking a new one
   closes all others and opens the new one.
   ─────────────────────────────────────────────────────────── */
function toggleService(item) {
    const isActive = item.classList.contains('active');
    document.querySelectorAll('.service-item.active')
            .forEach(el => el.classList.remove('active'));
    if (!isActive) item.classList.add('active');
}


/* ── SCROLL-BASED STICKY NAV INDICATOR ──────────────────────
   As the user scrolls through service items, the nav updates
   to show the current service number + name.
   Mirrors the Nakula reference behaviour.
   ─────────────────────────────────────────────────────────── */
(function initScrollIndicator() {
    const navNum  = document.getElementById('nav-svc-num');
    const navName = document.getElementById('nav-svc-name');
    if (!navNum || !navName) return;          // guard: elements not in page yet

    const items = document.querySelectorAll('.service-item[data-name]');
    if (!items.length) return;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                navNum.textContent  = entry.target.dataset.num  || '';
                navName.textContent = entry.target.dataset.name || '';
                navNum.classList.add('visible');
                navName.classList.add('visible');
            }
        });
    }, { threshold: 0.4 });

    items.forEach(item => observer.observe(item));

    // Hide indicator when services section is out of view
    const section = document.querySelector('.services-section');
    if (section) {
        const sectionObserver = new IntersectionObserver(([entry]) => {
            if (!entry.isIntersecting) {
                navNum.classList.remove('visible');
                navName.classList.remove('visible');
            }
        }, { threshold: 0 });
        sectionObserver.observe(section);
    }
})();


/* ── TODO: Process section interactions ──────────────────── */
/* ── TODO: FAQ accordion ─────────────────────────────────── */
